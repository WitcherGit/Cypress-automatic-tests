/// <reference types="cypress" />

describe("E2E - Dodanie poprawnej promocji przez liste towaru", () => {
    it("smoke test dodanie promocji", () => {
        cy.visit("/")
        cy.fixture("users").then(data => {
            cy.get('input[name="panel_login"]').type(data.username)
            cy.get('input[name="panel_password"]').type(data.password)
        })
        cy.get(".--full-sm").click();
        cy.get(':nth-child(6) > :nth-child(1) > .menu-text').click();
        cy.get('.open > .submenu > :nth-child(3) > .menu-url > span').click();
        cy.get('#products-list-id-17319 > label > .lbl').click();
        cy.get('#productsPromotionAction').click();
        cy.get('.sc-kDvujY > .sc-bBABsx > .sc-fLcnxK').then((btn) => {
            cy.wrap(btn).click();
            cy.wait(400);
            cy.get('#input_name').type('TEST-2-2077');
            cy.get('#input_new_price_value').clear().type(24.00);
            //checkboxy 
            cy.get('.lpeMnw > .jJdbZs > .sc-eDWCr > .bDLwm > .sc-fLcnxK').click();
            cy.get('.sc-eDWCr > :nth-child(1) > .sc-iJnaPW > label').click();
            //dodanie i zapis
            cy.get('.sc-hHTYSt > .sc-bBABsx > .sc-fLcnxK').click();
            cy.get('.fxbkTT > .alert-wrapper > .alert-actions > .gtnATL').click();
        })
    })
}) 