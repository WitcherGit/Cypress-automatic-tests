/// <reference types="cypress" />



describe("E2E - Dodanie importu towaru po pliku lokalnym", () => {
    it("smoke test import towaru", () => {
        cy.visit("/")
        cy.fixture("users").then(data => {
            cy.get('input[name="panel_login"]').type(data.username)
            cy.get('input[name="panel_password"]').type(data.password)
        })
        cy.get(".--full-sm").click();
        cy.get(':nth-child(6) > :nth-child(1) > .menu-text').click();
        cy.get('.open > .submenu > :nth-child(10) > .menu-url > span').click();
        cy.get('#elem_1').click();
        cy.get('.text-center > #elem_2').click();
        cy.get('#import_name').type("TEST-AUTOMATYCZNY");
        //wgrywanie pliku
        cy.get('input[type="file"]').attachFile("../fixtures/products.xml");
        //wybieranie elementu 
        cy.get('#view_template').select("Standard")
        cy.get('#iai-js-config-save-button').click()
        cy.wait(2000);
    })
})