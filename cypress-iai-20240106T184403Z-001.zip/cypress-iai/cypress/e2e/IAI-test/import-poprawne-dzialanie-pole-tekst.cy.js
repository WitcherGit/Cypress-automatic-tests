// /// <reference types="cypress" />



// describe("E2E - Dodanie importu towaru przez pole tekstowe", () => {
//     it("smoke test import towaru", () => {
//         cy.visit("/")
//         cy.fixture("users").then(data => {
//             cy.get('input[name="panel_login"]').type(data.username)
//             cy.get('input[name="panel_password"]').type(data.password)
//         })
//         cy.get(".--full-sm").click();
//         cy.get(':nth-child(6) > :nth-child(1) > .menu-text').click();
//         cy.get('.open > .submenu > :nth-child(10) > .menu-url > span').click();
//         cy.get('#elem_1').click();
//         cy.get('.text-center > #elem_2').click();
//         cy.get('#import_name').type("TEST-AUTOMATYCZNY-3");
//         cy.get('#import_type > :nth-child(3) > label > .lbl').click();

//         cy.fixture("product").then(data => {
//             cy.get('.tableRowTextarea').type()
//         })
   
//       //wybranie elementu po wartosci
//         cy.get('#view_template').select("23")
//         // cy.get('#iai-js-config-save-button').click();
//     })
// })
