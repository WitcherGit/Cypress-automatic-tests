/// <reference types="cypress" />

describe("E2E - Dodanie poprawnej promocji przez karte towaru", () => {
    it("smoke test dodanie promocji", () => {
        cy.visit("/")
        cy.fixture("users").then(data => {
            cy.get('input[name="panel_login"]').type(data.username)
            cy.get('input[name="panel_password"]').type(data.password)
        })
        cy.get(".--full-sm").click();
        cy.get('.aside_menu_search__input').type('17319');
        cy.get('.search_result__name').click();
        cy.wait(800);
        cy.get('#mainTabs-tab-9 > a').click();
        cy.wait(800);
        cy.get('#product-edit-aceform-marketing-elem-157').scrollIntoView();
        //dodanie promocji
        cy.get('#product-edit-aceform-marketing-elem-157').click();
        cy.get('.sc-kDvujY > .sc-bBABsx > .sc-fLcnxK').then((btn) => {
            cy.wrap(btn).click();
            cy.wait(400);
            cy.get('#input_name').type('TEST-2077');
            cy.get('#input_new_price_value').clear().type(15.00);
            //checkboxy 
            cy.get('.lpeMnw > .jJdbZs > .sc-eDWCr > .bDLwm > .sc-fLcnxK').click();
            cy.get('.sc-eDWCr > :nth-child(1) > .sc-iJnaPW > label').click();
            //dodanie i zapis
            cy.get('.sc-hHTYSt > .sc-bBABsx > .sc-fLcnxK').click();
            cy.get('.fxbkTT > .alert-wrapper > .alert-actions > .gtnATL').click();
        })
    })
}) 