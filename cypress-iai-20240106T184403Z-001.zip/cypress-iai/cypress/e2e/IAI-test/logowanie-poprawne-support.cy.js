/// <reference types="cypress" />


        //logowanie support
describe("E2E - Logowanie uzytkownika support", () => {
    it("login-support", () => {
        cy.visit("https://www.iai-system.com/panel")
        cy.fixture("users").then(data => {
            cy.get('#input_login').type(data.username, { cacheSession: false }) 
            cy.get(':nth-child(2) > :nth-child(2) > .forminput').type(data.password)
        })
        cy.get('.formbutton').click();
        cy.wait(300)
        cy.origin('https://trening-st30.iai-shop.com/panel/support-login', () => {
        cy.visit('https://www.iai-system.com/panel/support-login.php?type=panel&client=7551')
        cy.on('uncaught:exception', (err, runnable) => {
        return false
            })
        cy.wait(300)

        //podtrzymanie sesji
        cy.visit('https://www.iai-system.com/panel/support-login.php?type=panel&client=7551')
        cy.get('.menu-text').contains('SUPPORT').click();
    })
    })
})