/// <reference types="cypress" />

describe("E2E - przechwycenie zadania ", () => {
    it("weryfikacja requestu - metoda intercept", () => {
        cy.intercept("GET", "https://api.realworld.io/api/tags").as("GETrequestTAG")
        cy.visit("https://angular.realworld.io/")
        cy.wait("@GETrequestTAG")
        cy.get("@GETrequestTAG").then(res => {
            console.log(res)
            expect(res.response.statusCode).to.equal(200)
            expect(res.response.body.tags).to.contain("implementations").and.to.contain("welcome")
        })
    })    

    it("weryfikacja niepoprawnego logowania", () => {
        cy.visit("https://angular.realworld.io/")
        cy.get(".nav-item").contains("Sign in ").click()
        cy.login("test@mail.com", "haslo123")
        cy.get('.btn').click()
        cy.intercept("POST", "https://api.realworld.io/api/users/login").as("POSTrequestLOGIN")
        cy.wait("@POSTrequestLOGIN")
        cy.get("@POSTrequestLOGIN").then(res => {
            console.log(res)
            expect(res.response.statusCode).to.equal(403)
        })
    })

    it("Poprawne logowanie", function() {
        cy.intercept("GET", "https://api.realworld.io/api/tags", {fixture: 'tags.json'}).as("GETrequestTAG")
        cy.visit("https://angular.realworld.io/")
        cy.get(".nav-item").contains("Sign in ").click()
        cy.login("marcin.idosell@gmail.com", "haslomaslo")
        cy.get('.btn').click()
        cy.wait("@GETrequestTAG")

    })
})  