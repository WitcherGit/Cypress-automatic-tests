/// <reference types="cypress" />


describe("E2E -  Wykonywanie zapytania bezpośrednio do API", () => {
    beforeEach(function() {
        cy.fixture("example").then(data => {
            this.daneAPI = data;
        })
    })


    it("Autoryzacja + dodanie nowego artykułu", () => {
        const daneUser = {
            "user": {
                "email": "marcin.idosell@gmail.com",
                "password": "haslomaslo"
            }
        }

        const daneArticle = {
            "article": {
                "tagList": [], 
                "title": "test metoda POST", 
                "description": "test123", 
                "body": "test"
            }
        }

        cy.request("POST", "https://api.realworld.io/api/users/login", daneUser)
        .its("body").then(res => {
            const authToken = res.user.token;
            // console.log(authToken);

            cy.request({
                method: "POST", 
                url: "https://api.realworld.io/api/articles/",
                body: daneArticle,
                headers:  {
                    'Authorization': 'Token ' + authToken
                }
            }).then(res => {
                expect(res.status).to.equal(200)
            })
        })
    })    

})  