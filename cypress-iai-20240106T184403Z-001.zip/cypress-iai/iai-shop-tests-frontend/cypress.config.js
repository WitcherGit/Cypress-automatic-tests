const { defineConfig } = require("cypress");

module.exports = defineConfig({
  defaultCommandTimeout: 30000,
  retries: 2,
  e2e: {
    supportFile: false,
    setupNodeEvents(on, config) {

      on('task', {
        setMyValue: (val) => {
            return (order = val);
        },
        getMyValue: () => {
            return order;
        }
      })

      //zmienna z delivery @Gerard
      on('task', {
        setMyDeliver: (val) => {
          return (deliver = val);
        },
        getMyDeliver: () => {
          return deliver
        }
      })
      
      on('task', {
        setMyValueTwo: (val1) => {
            return (priceBefore = val1);
        },
        getMyValueTwo: () => {
            return priceBefore;
        }
      }),
      
      on('task', {
        setMyValueThird: (val2) => {
            return (priceAfter = val2);
        },
        getMyValuethird: () => {
            return priceAfter;
        }
      })
    },
  },
});
