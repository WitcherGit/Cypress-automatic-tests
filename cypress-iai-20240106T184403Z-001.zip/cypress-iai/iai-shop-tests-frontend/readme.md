# Testy E2E dla sklepów i paneli

Środowisko testowe w oparciu o Cypress.js

## Wymagania
- Node.js [Link](https://nodejs.org/en/download/)

## Instalacja lokalna

1. Pobierz repo na swój komputer
    ```sh
    git clone https://stash.iai-system.com/scm/iaishop/iai-shop-tests-frontend.git iai-shop-tests-frontend
    ```

2. Przejdź do katalogu z poziomu terminalu
    ```
    cd ./iai-shop-tests-frontend
    ```

3. Zainstaluj wymagane paczki
    ```sh
    npm install
    ```

4. Gotowe! :)


## Praca lokalna

Uruchomienie testów
```sh
npm start
```

Otwarcie narzędzia Cypress
```sh
npm run open
```