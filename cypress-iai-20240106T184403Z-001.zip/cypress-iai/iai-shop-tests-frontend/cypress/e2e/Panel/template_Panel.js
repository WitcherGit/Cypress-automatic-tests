/// <reference types="cypress" />
//Obsługa błędów - do dokończenia.
Cypress.on('uncaught:exception', (err, runnable) => {
    return false;
  });
//import funkcji - wejście na sklep, logowanie, dodanie do koszyka, wybór płatności, wybór dostawy 
//import { function1, function2, function3 } from "../../support/functions_file.js";

describe('TEST PANEL', () => {

    })