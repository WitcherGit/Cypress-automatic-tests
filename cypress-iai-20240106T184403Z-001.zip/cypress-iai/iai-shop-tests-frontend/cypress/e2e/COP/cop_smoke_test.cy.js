/// <reference types="cypress" />

//nie przejmujemy się błedami w konsoli, interesuje nas proces zakupowy, tzn. czy podstawowa nasza funkcjonalność działa
Cypress.on('uncaught:exception', (err, runnable) => {
    return cop_error_handling(err, runnable);
  })


//import funkcji - wejście na sklep, logowanie, dodanie do koszyka, wybór płatności, wybór dostawy 
import { cop_signup, cop_add_to_basket, cop_first_visit, cop_order1_step, cop_remove_all_from_basket, cop_order2_step, self_pickup_delivery, cop_order2_step, cop_verify_order_items, cop_error_handling } from "../../support/cop_smoke_function_list.js";

describe('INSTALCJA_TEST', () => {
    
    //wczytanie pilków konfiguracyjnych 
    const clients = require('../../fixtures/users_list.json')
    const products = require('../../fixtures/products_list.json')
    const payments = require('../../fixtures/payments_list.json')
    const deliveries = require('../../fixtures/deliveries_list.json')

   
         
    clients.forEach(clients =>
        {
            it('Smoke test for ' + clients.name, () => {
                //przejście do skelpu
                cop_first_visit();

                //zalogowanie
                cop_signup(clients.name,clients.password)

                //wyczyszczenie koszyka jeżeli coś w nim było dla danego klienta
                cop_remove_all_from_basket()    

            //dodawanie towarów do koszyka 
            products.forEach(products =>
                {
                cop_add_to_basket(products.id)
                }
            )
            //przejście koszyka dalej
            cy.get('.topBasket__sub').click()
            cy.get('#basket_go_next').click()

            //Wybranie płatności oraz dostawy  
            cop_order1_step(clients.id, payments, deliveries)

            //przejście dostawy
            cy.get('.summary__buttons > .btn').click()

            //sprawdzenie czy odbiór osobisty
            cy.task('getMyDeliver').then((deliver) => {
                self_pickup_delivery(deliver)
            })

            //Chceckboxy + finalizacja zakupu
            cop_order2_step()
    
            //złożenie zamówienia - order details, gdzie weryfikujemy ilość porduktów
            cop_verify_order_items(expected_items)
        });

        });
    })