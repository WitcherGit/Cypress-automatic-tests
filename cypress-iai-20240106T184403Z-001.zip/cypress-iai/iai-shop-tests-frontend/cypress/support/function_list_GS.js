export function cop_first_visit()
{
    cy.visit('https://trening-st23.iai-shop.com/')
}

export function cop_signup(name,password)
{
    cy.get('#ckdsclmrshtdwn_v2 > .ck_dsclr__btn_v2').click()
    cy.get('.account_link').click()
    cy.get('#user_login').type(name)
    cy.get('#user_pass').type(password)
    cy.get('form > .signin_buttons > .btn').click()
}

export function cop_add_to_basket(product_ids)
{
    cy.get('.menu_search__input').type(`${product_ids}{enter}`)
    if(product_ids==264){     
        cy.url().then(url => {
            let link = url
            link = link.split('?')[0]
            let params = "?selected_size=F"
            cy.visit(link + params)
        })
    }
    cy.get('#projector_button_basket').click()
    //cy.visit(product_ids)
    //dorobić ifa dla rozmiarowego by wybrać rozmiar 
}

export function cop_order1_step(client, payment, delivery )
{
    let pay
    let deliver
    if(client==43){
        pay = payment.filter((row) => row.id == "1")
        deliver = delivery.filter((row) => row.id == "3")
        cy.get(pay[0].locator).click()
        cy.get(deliver[0].locator).click()
    } 
    //wybranie platności oraz dostawy
}

export function cop_remove_all_from_basket()
{
    cy.get('.topBasket__sub').click()
    cy.get('body').then($body => {
    if ($body.find('.--remove-all').length > 0) {
        cy.get('.--remove-all').click()
    }
  })
}