export function cop_first_visit(){
    cy.visit('https://trening-st23.iai-shop.com/')
    cy.get('#ckdsclmrshtdwn_v2 > .ck_dsclr__btn_v2').click()  
}

export function cop_signup(name,password){
    cy.get('.account_link').click()
    cy.get('#user_login').type(name)
    cy.get('#user_pass').type(password)
    cy.get('form > .signin_buttons > .btn').click()
}

export function cop_add_to_basket(product_ids){
    cy.get('.menu_search__input').type(`${product_ids}{enter}`)
    if(product_ids==264){
        cy.url().then(url => {
            let link = url
            link = link.split('?')[0]
            let params = "?selected_size=F"
            cy.visit(link + params)
        })
    }
    cy.get('#projector_button_basket').click()
}

export function cop_remove_all_from_basket(){
    cy.get('.topBasket__sub').click()
    cy.get('body').then($body => {
    if ($body.find('.--remove-all').length > 0) {
        cy.get('.--remove-all').click()
    }
  })
}


export function cop_order1_step(client, payment, delivery)
{
    let pay
    let deliver
    if(client==43){
        pay = payment.filter((row) => row.id == "1")
        deliver = delivery.filter((row) => row.id == "1")
        cy.get(pay[0].locator).click()
        cy.get(deliver[0].locator).click()
    } 
    else if(client==44){
        //no i teraz tutaj podajemy inne idiki dla platnosci i dostawy 
        
        pay = payment.filter((row) => row.id == "2")
        deliver = delivery.filter((row) => row.id == "4")
        cy.get(pay[0].locator).click()
        cy.get(deliver[0].locator).click()
        

    } else if(client==45){
        //no i teraz tutaj podajemy inne idiki dla platnosci i dostawy
        
        pay = payment.filter((row) => row.id == "3")
        deliver = delivery.filter((row) => row.id == "4")
        cy.get(pay[0].locator).click()
        cy.get(deliver[0].locator).click()
        

   } else if(client==46){
        //no i teraz tutaj podajemy inne idiki dla platnosci i dostawy 
        
        pay = payment.filter((row) => row.id == "4")
        deliver = delivery.filter((row) => row.id == "3")
        cy.get(pay[0].locator).click()
        cy.get(deliver[0].locator).click()
        
   }
}

cy.task('setMyDeliver', deliver[0])

export function self_pickup_delivery(deliver)
{
    //robocze
    if(deliver.selfPickup === "t"){
        cy.get('.asideContainer_pickup > .pickup_point').click()
        cy.get(':nth-child(2) > .pickupl_date_sub').click()
        cy.get('.pickupl_submit > .btn').click()

    } 

}

export function cop_order2_step()
{
    cy.get('body')
    .then(($body) => {
        if ($body.find('.order2_terms_conditions > .css-label').length) {
            cy.get('.order2_terms_conditions > .css-label').click()}
        if ($body.find('.order2_cancel > .css-label').length) {
            cy.get('.order2_cancel > .css-label').click()}
        if ($body.find('.order2_virtual > .css-label').length) {
            cy.get('.order2_virtual > .css-label').click()}
        if ($body.find('.order2_service > .css-label').length) {
            cy.get('.order2_service > .css-label').click()}
    })
    cy.get('.btn_wrapper > .btn').click()  //click kup
}

export function cop_verify_order_items(expected_items)
{
    cy.log('Products number from json files:', expected_items)
    let basket_elements = 0
    cy.wait(1000)
   
    cy.get('.ordered_product__content > div.ordered_product__name > .ordered_product__name').then($elements => {
        basket_elements = $elements.length 
        cy.log('Products on orderdetails site:', basket_elements)
        if(expected_items == basket_elements){
            cy.log("Number of items - OK")
        }else{
            cy.contains("Number of items - FAIL")
            //throw new Error("test failed")
        }
    })

}

export function cop_error_handling(err, runnable)
{
    return false;
}