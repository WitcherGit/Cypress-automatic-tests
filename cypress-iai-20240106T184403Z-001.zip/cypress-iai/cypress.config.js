const { defineConfig } = require("cypress");

module.exports = defineConfig({
  e2e: {
    baseUrl: "https://trening-st30.iai-shop.com/panel",
    includeShadowDom: true,
    chromeWebSecurity: true,
    viewportHeight: 1080,
    viewportWidth: 1920,
    "theme": "dark",
    "reporter": 'cypress-multi-reporters',
    "reporterOptions": {
    "configFile": 'reporter-config.json'
    }
  },
});

