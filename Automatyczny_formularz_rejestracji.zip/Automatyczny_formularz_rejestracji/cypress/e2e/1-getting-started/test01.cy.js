describe("weryfikacja", () => {

    it('click the button', () => {
        cy.visit('http://127.0.0.1:5500/www/index2.html')

        cy.get("button[type='button']").click();
        cy.get("#email").type("test@mail.com")

        const password = 'TEST123'
        cy.get("#psw").type(password);
        cy.get("#psw-repeat").type(password);

        cy.wait(1000)
        cy.get("button[type='button']").click();
    })
})


