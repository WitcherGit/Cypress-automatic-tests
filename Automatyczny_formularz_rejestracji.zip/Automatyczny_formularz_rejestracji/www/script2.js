const burgerBtn = document.querySelector('.burger')
const plusBtn = document.querySelector('.plus')
const minusBtn = document.querySelector('.minus')
const nav = document.querySelector('nav ul')

const handleNav = () => {
    nav.classList.toggle('active')
    burgerBtn.classList.toggle('active')
    plusBtn.classList.toggle('hide')
    minusBtn.classList.toggle('hide')

}

burgerBtn.addEventListener('click', handleNav)